import streamlit as st
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Sample data - replace this with your actual data
data = {'title': ['Toy Story', 'Jumanji', 'Grumpier Old Men', 'Waiting to Exhale', 'Father of the Bride Part II'],
        'genres': ['Adventure|Animation|Children|Comedy|Fantasy', 'Adventure|Children|Fantasy', 'Comedy|Romance', 'Comedy|Drama|Romance', 'Comedy']}
df = pd.DataFrame(data)

# Create a CountVectorizer instance
cv = CountVectorizer(max_features=10000, stop_words='english')

# Fit and transform the 'genres' column to create the 'vec' variable
vec = cv.fit_transform(df['genres'])

# Calculate the cosine similarity matrix
sim = cosine_similarity(vec)

# Function to recommend movies
def recommend(movie_title):
    if movie_title not in df['title'].values:
        st.write(f"Movie '{movie_title}' not found in the dataset.")
        return
    index = df[df['title'] == movie_title].index[0]
    dist = sorted(list(enumerate(sim[index])), reverse=True, key=lambda x: x[1])
    recommendations = [df.iloc[i[0]]['title'] for i in dist[1:6]]  # Skip the first one as it will be the movie itself
    return recommendations

# Streamlit app
st.title("Movie Recommendation System")
movie_title = st.text_input("Enter a movie title:")
if st.button("Recommend"):
    recommendations = recommend(movie_title)
    if recommendations:
        st.write("Recommended movies:")
        for movie in recommendations:
            st.write(movie)
    
    