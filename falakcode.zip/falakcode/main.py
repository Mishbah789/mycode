import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Sample data - replace this with your actual data
data = {'title': ['Toy Story', 'Jumanji', 'Grumpier Old Men', 'Waiting to Exhale', 'Father of the Bride Part II'],
        'genres': ['Adventure|Animation|Children|Comedy|Fantasy', 'Adventure|Children|Fantasy', 'Comedy|Romance', 'Comedy|Drama|Romance', 'Comedy']}
df = pd.DataFrame(data)

# Create a CountVectorizer instance
cv = CountVectorizer(max_features=10000, stop_words='english')

# Fit and transform the 'genres' column to create the 'vec' variable
vec = cv.fit_transform(df['genres'])

# Calculate the cosine similarity matrix
sim = cosine_similarity(vec)

# Function to recommend movies
def recommend(movie_title):
    if movie_title not in df['title'].values:
        print(f"Movie '{movie_title}' not found in the dataset.")
        return
    index = df[df['title'] == movie_title].index[0]
    dist = sorted(list(enumerate(sim[index])), reverse=True, key=lambda x: x[1])
    for i in dist[1:6]:  # Skip the first one as it will be the movie itself
        print(df.iloc[i[0]]['title'])

# Test the recommendain.pation function
recommend('Toy Story') 